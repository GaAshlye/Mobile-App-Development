import React from "react";
class submit extends Component {
    state = {  }
    render() { 
        return ( 
            <button class="btn btn-primary"
          type="submit">Submit</button>
         );
    }
}
 
export default submit;